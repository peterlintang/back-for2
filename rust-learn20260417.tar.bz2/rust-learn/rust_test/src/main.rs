
use std::fs::File;
use std::io::ErrorKind;

fn main() {
    /*
    let mut v = Vec::new();
//    let v = vec![1,2,3];
//    let exist = &v[100];
    v.push(10);
    v.push(9);
    v.push(8);
    v.push(7);
    v.push(6);
    v.push(5);
    v.push(4);
    v.push(3);
    v.push(2);
    v.push(1);
    v.push(0);
    v.push(-1);
    println!("Hello, world! {:?}", v.get(0));
    for i in &mut v
    {
        *i += 6;
    }
    for i in &v
    {
        println!("i: {i}");
    }
    */
    /*
    let mut s = String::new();
    let data = "hello world!";
    s = data.to_string();
    s.push_str("nice");
    println!("s:{s}");
    let s1 = String::from("1");
    let s2 = String::from("2");
    let s3 = String::from("3");
    let s4 = format!("{s1}-{s2}-{s3}");
    println!("{s4}");
    */

    /*
    use std::collections::HashMap;
    let mut scores = HashMap::new();

    scores.insert(String::from("Blue"), 10);
    scores.insert(String::from("Yellow"), 50);

    for (key, value) in &scores 
    {
        println!("{key}:{value}");
    }

    let mut map = HashMap::new();
    let text = "hello world wonderful world";

    for word in text.split_whitespace()
    {
        let count = map.entry(word).or_insert(0);
        *count += 1;
    }
    println!("{map:?}");
//    panic!("crash and burn");
    let v = vec![1, 2, 3];
    v[99];
    */
    let greeting_file_result = File::open("hello.txt");
    let result = match greeting_file_result
    {
        Ok(file) => file,
        Err(err) => match err.kind()
        {
            ErrorKind::NotFound => match File::create("hello.txt")
            {
                Ok(file) => file,
                Err(e) => panic!("create file failed {e}"),
            },
            _ =>  
            {
                panic!("open file failed {err}");
            }
        },
    };

    let v1 = vec![ 1, 2, 3 ];
    let v1_iter = v1.iter();

    for val in v1_iter
    {
        println!("val: {val}");
    }
}

#[test]
fn iterator_demon()
{
    let v1 = vec![1, 2, 3];
    let mut v1_iter = v1.iter();

    assert_eq!(v1_iter.next(), Some(&1));
    assert_eq!(v1_iter.next(), Some(&2));
    assert_eq!(v1_iter.next(), Some(&3));
    assert_eq!(v1_iter.next(), None);
}

#[test]
fn iterator_sum()
{
    let v1 = vec![1, 2, 3];
    let v1_iter = v1.iter();

    let total: i32 = v1_iter.sum();
    assert_eq!(total, 6);


    let v2: Vec<i32> = vec![1, 2, 3];
    let v3: Vec<_> = v2.iter().map(|x| x + 1).collect();
    assert_eq!(v3, vec![2, 3, 4]);
}








