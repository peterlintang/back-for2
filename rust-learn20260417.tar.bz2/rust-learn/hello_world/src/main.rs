fn main() {
    let mut x = 5;
    if x < 5
    {
        println!("The value of x is: {x} little");
    }
    else if x < 8
    {
//        x = 6;
        println!("The value of x is: {x} middle");
    }
    else
    {
        println!("The value of x is: {x} ou");
    }
    'oo: loop
    {
        x = x + 1;
        if x == 20
        {
            break 'oo;
        }
        println!("again");
    };

    let mut num = 5;
    while num != 0
    {
        println!("num: {num}");
        num = num - 1;
    }

    let a = [ 1, 2, 3, 4, 5, 6];
    for element in a
    {
        println!("element: {element}");
    }

    for element in (2..4).rev()
    {
        println!("element: {element}");
    }

    let mut s = String::from("hello");
    s.push_str(" world!");
    println!("{s}");

    let s_slice = &s[0..3];
    let s2_slice = &s[3..];
    println!("s_slice: {s_slice}");
    println!("s2_slice: {s2_slice}");

    println!("coin: {}", value_in_cents(Coin::Penny));
    println!("coin: {}", value_in_cents(Coin::Nickel));
    println!("coin: {}", value_in_cents(Coin::Dime));
    println!("coin: {}", value_in_cents(Coin::Quarter(UsState::Alabana)));
    let five = Some(5);
    println!("plus_: {:?}", plus_one(five));
    println!("plus_: {:?}", plus_one(None));
}

#[derive(Debug)]
enum UsState {
    Alabana,
    Alaska
}

enum Coin {
    Penny,
    Nickel,
    Dime,
    Quarter(UsState)
}

fn value_in_cents(coin: Coin) -> u8
{
    match coin
    {
        Coin::Penny => {
            println!("good");
            1
        }
        Coin::Nickel => 5,
        Coin::Dime => 10,
        Coin::Quarter(state) => {
            println!("state: {state:?}!");
            25
        }
    }
}

fn plus_one(x: Option<i32>) -> Option<i32>
{
    match x
    {
        None => None,
        Some(i) => Some(i + 1),
    }
}







