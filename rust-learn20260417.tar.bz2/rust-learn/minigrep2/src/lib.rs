
pub fn search<'a>(query: &str, contents: &'a str) -> Vec<&'a str>
{
    contents.lines().filter(|line| line.contains(query)).collect()
    /*
    let mut results = Vec::new();
    for line in contents.lines()
    {
        if line.contains(query)
        {
            results.push(line);
        }
    }

    results
    */
}

pub fn search_case_insensitive<'a>(query: &str, contents: &'a str) -> Vec<&'a str>
{
    let mut results = Vec::new();
    let query = query.to_lowercase();

    for line in contents.lines()
    {
        if line.to_lowercase().contains(&query)
        {
            results.push(line);
        }
    }

    results
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn case_sensitive()
    {
        let query = "duct";
        let contents = "\
rust:
safe, fast, productive.
pick there";

        assert_eq!(vec!["safe, fast, productive."], search(query, contents));
    }

    #[test]
    fn case_insensitive()
    {
        let query = "ducT";
        let contents = "\
rust:
safe, fast, productive.
pick there";

        assert_eq!(vec!["safe, fast, productive."], search_case_insensitive(query, contents));
    }
}
