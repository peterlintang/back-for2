
/*
fn main() {
    let width = 80;
    let height = 80;
    println!("Hello, world! {}", area(width, height));
}

fn area(width: u32, height: u32) -> u32
{
    width * height
}
*/
/*
fn main() {
    let rect = (31, 32);
    println!("Hello, world! {}", area(rect));
}

fn area(dimensions: (u32, u32)) -> u32
{
    dimensions.0 * dimensions.1 
}
*/

/*
struct Rect {
    width: u32,
    height: u32,
}

fn main()
{
    let rect1 = Rect {
        width: 32,
        height: 64,
    };
    println!("Hello, world! {}", area(&rect1));
}

fn area(rectangle: &Rect) -> u32
{
     rectangle.width * rectangle.height 
}
*/
struct Rect {
    width: u32,
    height: u32,
}

impl Rect {
    fn area(self: &Self) -> u32
    {
        self.width * self.height
    }
    fn can_hold(&self, other: &Rect) -> bool
    {
        /*
        self.width > other.width && self.height > other.height
        */
        if self.width > other.width && self.height > other.height
        {
            //return true
            true
        }
        else
        {
            //return false
            false
        }
    }
//    fn new(width: u32, height: u32) -> Rect
    fn new(width: u32, height: u32) -> Self
    {
        Rect {
            width,
            height,
        }
    }
}

fn main()
{
    let rect1 = Rect {
        width: 32,
        height: 64,
    };
    let other = Rect {
        width: 16,
        height: 18,
    };
    let rect2 = Rect::new(15, 15);
    println!("Hello, world! {}, {}", rect1.area(), rect1.can_hold(&other));
    println!("rect2: {} {}", rect2.width, rect2.height);
}

