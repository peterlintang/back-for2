
fn main() {
    
    let four = IpAddrKind::V4;
    let six = IpAddrKind::V6;

    route(IpAddrKind::V4);
    route(IpAddrKind::V6);

    println!("{:?} {:?}", four, six);
    println!("{}", IpAddrKind::V4 as i32);
    println!("{}", IpAddrKind::V6 as i32);
    

    let home = IpAddr::V4(String::from("127.0.0.1"));
    let loopback = IpAddr::V6(String::from("::1"));
    let IpAddr::V4(x) = home else { todo!() };
    println!("{}", x);
    loopback.route2();
//    println!("{:?} {:?}", home, loopback);
    println!("value {}", value_in_cents(Coin::Quarter(UsState::Alaska)));

    let config_max = Some(8u8);
    if let Some(max) = config_max {
        println!("max: {max}");
    }

    if let Some(max) = config_max {
        println!("max: {max}");
    }
    else
    {
    }

    match config_max {
        Some(max) => println!("match max: {max}"),
        _ => (),
    }
}


#[derive(Debug)]
enum IpAddrKind {
    V4 = 4,
    V6,
}

fn route(_ip_kind: IpAddrKind)
{
}


#[derive(Debug)]
enum IpAddr {
    V4(String),
    V6(String),
}

impl IpAddr {
    fn route2(&self)
    {
        println!("hello enum method {:?}", self);
    }
}

#[derive(Debug)]
enum UsState {
    Alabama,
    Alaska,
}

enum Coin {
    Penny,
    Nickel,
    Dime,
    Quarter(UsState),
}

fn value_in_cents(coin: Coin) -> u8
{
    match coin {
        Coin::Penny => 1,
        Coin::Nickel => 5,
        Coin::Dime => 10,
        Coin::Quarter(state) => {
            println!("state {state:?}");
            25
        }
    }
}


