
use std::sync::Mutex;
use std::sync::Arc;
use std::thread;
//use std::rc::Rc;

fn main() {
    /*
    let m = Mutex::new(5);
    {
        let mut num = m.lock().unwrap();
        *num = 6;
    }
    println!("m: {m:?}");
    */
    let count = Arc::new(Mutex::new(0));
    let mut handles = vec![];

    for _ in 0..10
    {
        let count = Arc::clone(&count);
        let handle = thread::spawn(
            move || 
            {
                let mut num = count.lock().unwrap();
                *num += 1;
            }
            );
        handles.push(handle);
    }

    for handle in handles
    {
        handle.join().unwrap();
    }

    println!("count: {count:?}");
}
