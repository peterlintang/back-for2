
use std::thread;
use std::time::Duration;
use std::sync::mpsc;

fn main() {
    let v = vec![1,2,3];
    let handle = thread::spawn(move || {
        for i in 1..10
        {
            println!("hi number {i} from the spawned thread! {v:?}");
            thread::sleep(Duration::from_millis(1));
        }
    });

    for i in 1..5
    {
        println!("hi number {i} from the main thread!");
        thread::sleep(Duration::from_millis(1));
    }

    handle.join().unwrap();

    let (tx, rx) = mpsc::channel();

    let tx1 = tx.clone();
    thread::spawn(move || {
        let vals = vec![
            String::from("more"),
            String::from("two"),
            String::from("module"),
            String::from("message"),
        ];

        for val in vals {
            tx1.send(val).unwrap();
            thread::sleep(Duration::from_secs(1));
        }
    });

    thread::spawn(move || {
        let vals = vec![
            String::from("hi"),
            String::from("from"),
            String::from("the"),
            String::from("thread"),
            ];
        for val in vals
        {
            tx.send(val).unwrap();
            thread::sleep(Duration::from_secs(1));
//          println!("val: {val}");
        }
    });

    for received in rx
    {
        println!("Got: {received}");
    }
    /*
    let received = rx.recv().unwrap();
    println!("Got: {received}");
    */
}


