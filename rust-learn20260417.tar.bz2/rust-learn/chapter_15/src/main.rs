
#[derive(Debug)]
enum List {
    Cons(i32, Box<List>),
    Nil,
}

use crate::List::{Cons, Nil};

fn main() {
    let list = Cons(1, Box::new(Cons(2, Box::new(Cons(3, Box::new(Nil))))));
    let b = Box::new(5);
    println!("b: {b}");
    println!("list: {list:?}");

    let x = 5;
    let y = &x;
    let y2 = Box::new(x);

    assert_eq!(x, 5);
    assert_eq!(*y, 5);
    assert_eq!(*y2, 5);
    println!("y: {y}");
    println!("y2: {y2}");
}
