
fn main() {
    let num_list = vec![12, 1, 2, 3, 5, 6, 8, 9, 4, 10];

    let large = largest_i32(&num_list);
    println!("large i32: {large}");

    let char_list = vec!['a', 'c', 'e', 'f', 'o', 'b'];

    let large = largest_char(&char_list);
    println!("large char: {large}");

    let large = largest(&num_list);
    println!("large : {large}");
    let large = largest(&char_list);
    println!("large : {large}");

    let _both_integer = Point { x: 5, y: 10 };
    let _both_float = Point { x: 1.0, y: 4.0 };
    let integer_and_float = Point { x: 5, y: 4.0 };

    println!("x: {}, y: {}", 
             integer_and_float.x(), integer_and_float.y()
             );


    let post = SocialPost {
        username: String::from("horse_ebooks"),
        content: String::from(
            "of course, as you probably already know, people",
        ),
        reply: false,
        repost: false,
    };

    println!("1 new post: {}", post.summarize());


    let article = NewsArticle {
        headline: String::from("Penguins win the Stanley Cup Championship!"),
        location: String::from("Pittsburgh, PA, USA"),
        author: String::from("Iceburgh"),
        content: String::from(
            "The Pittsburgh Penguins once again are the best \
             hockey team in the NHL.",
        ),
    };

    println!("New article available! {}", article.summarize());

    notify(&article);
    notify(&post);
}


fn largest_i32(list: &[i32]) -> &i32
{
    let mut large = &list[0];

    for item in list
    {
        if item > large
        {
            large = item;
        }
    }

    large
}


fn largest_char(list: &[char]) -> &char
{
    let mut large = &list[0];

    for item in list
    {
        if item > large
        {
            large = item;
        }
    }

    large
}

fn largest<T: PartialOrd>(list: &[T]) -> &T
{
    let mut large = &list[0];

    for item in list
    {
        if item > large
        {
            large = item;
        }
    }

    large
}


struct Point<T, U>
{
    x: T,
    y: U,
}

impl<T, U> Point<T, U> 
{
    fn x(&self) -> &T
    {
        &self.x
    }
    fn y(&self) -> &U
    {
        &self.y
    }
}

pub trait Summary {
    fn summarize(&self) -> String;
}

pub struct NewsArticle {
    pub headline: String,
    pub location: String,
    pub author: String,
    pub content: String,
}

impl Summary for NewsArticle {
    fn summarize(&self) -> String {
        format!("{}, by {} ({})", self.headline, self.author, self.location)
    }
}

pub struct SocialPost {
    pub username: String,
    pub content: String,
    pub reply: bool,
    pub repost: bool,
}

impl Summary for SocialPost {
    fn summarize(&self) -> String {
        format!("{}: {}", self.username, self.content)
    }
}

pub fn notify(item: &impl Summary) {
    println!("Breaking news! {}", item.summarize());
}
