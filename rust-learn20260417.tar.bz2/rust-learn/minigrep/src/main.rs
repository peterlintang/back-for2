
use std::env;
use std::fs;
use std::process;
use std::error::Error;
use minigrep::search;
use minigrep::search_case_insensitive;

fn main() {

    let args: Vec<String> = env::args().collect();

    /*
    for i in &args
    {
        println!("we are: {i}");
    }

    let query = &args[1];
    let file_path = &args[2];
    */
    let config = Config::build(&args).unwrap_or_else(|err|
                      { eprintln!("problem parsing args: {err}");
                        process::exit(1)
                      });

    /*
    println!("search {}", config.query);
    println!("in file {}", config.file_path);
    */

    if let Err(e) = run(config)
    {
        eprintln!("Application error: {e}");
        process::exit(1);
    }
//    dbg!(args);
}

pub struct Config
{
    pub query: String,
    pub file_path: String,
    pub ignore_case: bool,
}

impl Config {
    fn build(args: &[String]) -> Result<Config, &'static str>
    {
        if args.len() < 3
        {
            return Err("Not enought args");
        }

        let query = args[1].clone();
        let file_path = args[2].clone();
        let ignore_case = env::var("IGNORE_CASE").is_ok();

        Ok(Config {query, file_path, ignore_case})
    }
}

fn run(config: Config) -> Result<(), Box<dyn Error>>
{
    let contents = fs::read_to_string(config.file_path)?;

    /*
    let line = search(&config.query, &contents);
    println!("{line:?}");
    */
    
//    println!("contents: {contents}");
    let results = if config.ignore_case
    {
        search_case_insensitive(&config.query, &contents)
    }
    else
    {
        search(&config.query, &contents)
    };

    for line in results
    {
        println!("{line}");
    }
    

    Ok(())
}



