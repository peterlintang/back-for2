
fn main() {
    let str1 = String::from("hello world!");
    let a;
    {
        let str2 = String::from("ni hao! shi jie mei hao");
        a = longest(&str1, &str2);
        println!("longest: {a}");
    }
    
    let x = 3;
    let y = 8;
    println!("max: {}", max(&x, &y));

    let s: &'static str = "I have a static lifetime";
}

fn longest<'a>(str1: &'a str, str2: &'a str) -> &'a str
{
    if str1.len() > str2.len()
    {
        str1
    }
    else
    {
        str2
    }
}
fn max<'a, T: PartialOrd>(x: &'a T, y: &'a T) -> &'a T
{
    if x > y
    {
        x
    }
    else
    {
        y
    }
}
