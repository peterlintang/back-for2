
use adder::add;

#[test]
fn it_add_two()
{
    let ret = add(3, 5);
    assert_eq!(ret, 8);
}
